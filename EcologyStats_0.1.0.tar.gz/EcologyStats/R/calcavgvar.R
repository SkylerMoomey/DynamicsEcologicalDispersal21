#' A function to calculate the mean and variance of the 16 variables over many resamples
#'
#' @param data data frame containing the values calculated by repeated uses of lattice_calc.R
#'
#' @return a two-column data frame indexed by w containing the average and variance of each population density
#' @export
#'
#' @examples all_data <- rep(0.1, 17)
#' all_data <- matrix(all_data, nrow=1, ncol=17)
#' all_data <- data.frame(all_data); calcavgvar(all_data)
calcavgvar=function(all_data) {

  #variable to house dataframe containing all variable information for each value of w
  dataset <- c()

  #sentinel variable set with very first value of w, will be continuously rechecked
  w = all_data[1,1]

  #count for entire loop
  i=1

  #count for particular set of data in dataset
  current_data_length = 0

  #variable to house the means and variances as they are calculated
  avgvar.df <- c()

  #loop through every row in the data
  while(i <= nrow(all_data)) {

    #if the data value of w matches the current value of w, add it to dataset
    if(all_data[i,1]==w) {

      #add row to dataset
      dataset = c(dataset, all_data[i,])

      #increment current dataset counter
      current_data_length = current_data_length + 1

      #on the last iteration, finish the data processes
      if(i==nrow(all_data)) {

        dataset <- matrix(dataset, current_data_length, ncol(all_data), byrow=TRUE)
        dataset <- data.frame(dataset)

        #last iteration, add last iteration of dataset averages and variances to avgvar.df
        for(name in names(dataset)) {

          curr_col <- as.numeric(dataset[[name]])
          avgvar.df <- c(avgvar.df, mean(as.numeric(curr_col)))
          avgvar.df <- c(avgvar.df, var(as.numeric(curr_col)))
        }

      }

      i = i + 1 #increment i only when this part runs
      next #skip iteration if the w's match
    }

    #if the w's do not match, we know we've reached the end of a particular resample. In this case, package the data we have so far
    dataset <- matrix(dataset, current_data_length, ncol(all_data), byrow=TRUE)
    current_data_length = 0
    dataset <- data.frame(dataset)

    #now, for each column in dataset, calculate the mean and variance and add it to avgvar.df
    for(name in names(dataset)) {

      curr_col <- as.numeric(dataset[[name]])
      avgvar.df <- c(avgvar.df, mean(as.numeric(curr_col)))
      avgvar.df <- c(avgvar.df, var(as.numeric(curr_col)))
    }

    #clear dataset to allow for adding next value of w
    dataset <- c()

    #change w to the current row in the data
    w = all_data[i,1]
  }

  #create column names for avgvar.df
  columns2 <- c("mean(w)", "var(w)", "mean(G+)", "var(G+)","mean(H+)", "var(H+)","mean(G++)", "var(G++)","mean(H++)", "var(H++)",
                "mean(S++)", "var(S++)","mean(C++)", "var(C++)","mean(G+0)", "var(G+0)","mean(H+0)", "var(H+0)","mean(S+0)", "var(S+0)",
                "mean(C+0)", "var(C+0)","mean(S0+)", "var(S0+)","mean(C0+)", "var(C0+)","mean(G00)", "var(G00)","mean(H00)", "var(H00)",
                "mean(S00)", "var(S00)","mean(C00)", "var(C00)")

  #convert avgvar.df to a data frame
  avgvar.df <- matrix(avgvar.df, ncol = 2*ncol(all_data), byrow=TRUE)
  avgvar.df <- data.frame(avgvar.df)

  colnames(avgvar.df) <- columns2

  return(avgvar.df)
}
