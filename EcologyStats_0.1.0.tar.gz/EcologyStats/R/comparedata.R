#' Compares model data to statistical data calculated from repeated resamplings of the dispersal simulation
#'
#' @param model_output.df name of data frame containing numerical output from the model
#' @param mean_and_var.df name of data frame containing the mean and variances from repeated resamplings of the simulation
#'
#' @return a data frame containing TRUE and FALSE, indexed by w in the rows and each variable in the columns. TRUE is returning if the model data is within +-variance of the average of the resamples.
#' @export
#'
#' @examples file_path = "/Users/skylermoomey/Desktop/Research Functions/simulation_statistics/EcologyStats/csv/model_output_3over8.csv"
#' model_output <- read.csv(file_path)
#' true_false.df <- c()
#' mean_and_var <- c(0.0025, rep(0.0002, 33))
#' mean_and_var <- c(mean_and_var,rep(mean_and_var, 398))
#' mean_and_var <- matrix(mean_and_var, 399, 34, byrow=TRUE)
#' mean_and_var <- data.frame(mean_and_var)
#' comparedata(model_output, mean_and_var)
comparedata = function(model_output.df, mean_and_var.df) {

  #note that model_output.df and mean_and_var.df should have the same number of columns and rows

  #create true_false.df object
  true_false.df <- c()

  #increment through all rows
  for(i in 1:nrow(model_output.df)) {

    #we don't care about the w column, these will be the same
    for(j in 2:ncol(model_output.df)) {

      #if the model data is within the mean plus or minus the variance, put a true in the data frame, else false
      if(abs(mean_and_var.df[i, 2*j - 1] - mean_and_var.df[i, 2*j])  <= model_output.df[i,j] && model_output.df[i,j] <= abs(mean_and_var.df[i, 2*j - 1] + mean_and_var.df[i, 2*j])) {

        true_false.df <- c(true_false.df, TRUE)
      }
      else {

        true_false.df <- c(true_false.df, FALSE)
      }

    }
  }

  #convert to a data frame
  true_false.df <- matrix(true_false.df, 399, 16, byrow=TRUE)
  true_false.df <- data.frame(true_false.df)

  #return the true_false matrix, should be simple to calculate percent accuracy based on this
  return(true_false.df)

}
