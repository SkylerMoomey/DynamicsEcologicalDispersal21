#' Calculates probabilities on a single matrix
#'
#' @param lattice is a two-dimensional matrix on which to perform calculations
#' @param w is the floating point between 0 and 1 for which the matrix corresponds. Represents perceptual capacity.
#' @param option option can be an integer equal to the values 1 or 2. Option 1 is the default and calculates the values G_+ and H_+. Option 2 calculates G_+, H_+, G_++, H_++, S_++, and C_++, G_+0, H_+0, S_+0, C_+0, S_0+, C_0+, G_00, H_00, S_00, C_00.
#'
#' @return a list whose first entry is w and whose following values are the densities corresponding to the option selected
#' @export
#'
#' @examples mat <- c(0, 1, 2, 3); mat <- matrix(mat, 2, 2); lattice_calc(mat, w=0.5)
lattice_calc=function(lattice, w, option=1) {

  n = nrow(lattice)
  all_counts <- list(w)

  total_patches = n^2
  total_pairs = 4*n^2

  Gplus = 0
  Hplus = 0

  #for all options, loop through lattice and count up G_+ and H_+
  for(i in 1:nrow(lattice)) {
    for(j in 1:ncol(lattice)) {


      #determines if we are at a favorable patch
      if((i%%2 == 0 & j%%2==0) | (i%%2 == 1 & j%%2 == 1)){

        #determines if favorable spot is occupied or not. If yes, increment Gplus.
        if(lattice[i,j] == 3) {Gplus = Gplus + 1}
      }
    #if we are not at a favorable patch, check if occupied
    else{

        if(lattice[i,j] == 1) {Hplus = Hplus + 1}
    }
    }
  }

  all_counts <- c(all_counts, Gplus/total_patches, Hplus/total_patches)

  #begin looping through indexes and counting neighbors. Only counts 4 of the 8 possible directions to avoid miscounting
  if(option == 2) {

    Gplusplus=0
    Hplusplus=0
    Splusplus=0
    Cplusplus=0
    Gpluszero=0
    Hpluszero=0
    Spluszero=0
    Cpluszero=0
    Szeroplus=0
    Czeroplus=0
    Gzerozero=0
    Hzerozero=0
    Szerozero=0
    Czerozero=0

    #loop through lattice again and begin to count pairs
    #i is row index
    #j is column index
    #This setup uses modualr arithmetic in order to count over the edges of the lattice.
    for(i in 0:(nrow(lattice) - 1)) {
      for(j in 0:(ncol(lattice) - 1)) {

          #use modular arithmetic to count neighbors in the four directions, bottom-left, down, bottom-right, right
          #this allows us to count pairs across the edges of the lattice

            #check if we're at a desirable, propagated
            if(lattice[i%%n + 1,j%%n + 1] == 3) {

              #check lower-left is desirable, propagated
              if(lattice[(i + 1)%%n + 1, (j - 1)%%n + 1] == 3) {Gplusplus = Gplusplus + 1}
              #else it is desirable, unpropagated
              else {Gpluszero = Gpluszero + 1}

              #check bottom is undesirable, propagated
              if(lattice[(i + 1)%%n + 1, j%%n + 1] == 1) {Splusplus = Splusplus + 1}
              #else it is undesirable, unpropagated
              else {Spluszero = Spluszero + 1}

              #check lower-right desirable, propagated
              if(lattice[(i + 1)%%n + 1, (j + 1)%%n + 1] == 3) {Gplusplus = Gplusplus + 1}
              #else it is desirable, unpropagated
              else {Gpluszero = Gpluszero + 1}

              #check right is undesirable, propagated
              if(lattice[i%%n + 1, (j + 1)%%n + 1] == 1) {Splusplus = Splusplus + 1}
              #else it is undesirable, unpropagated
              else {Spluszero = Spluszero + 1}

            }

            #check if we're at an undesirable, propagated
            if(lattice[i%%n + 1,j%%n  + 1] == 1) {

              #check lower-left is undesirable, propagated
              if(lattice[(i + 1)%%n + 1, (j - 1)%%n + 1] == 1) {Hplusplus = Hplusplus + 1}
              #else it is undesirable, unpropagated
              else {Hpluszero = Hpluszero + 1}

              #check bottom is desirable, propagated
              if(lattice[(i + 1)%%n + 1, j%%n + 1] == 3) {Cplusplus = Cplusplus + 1}
              #else it is desirable, unpropagated
              else {Cpluszero = Cpluszero + 1}

              #check lower-right is undesirable, propagated
              if(lattice[(i + 1)%%n + 1, (j + 1)%%n + 1] == 1) {Hplusplus = Hplusplus + 1}
              #else it is undesirable, unpropagated
              else {Hpluszero = Hpluszero + 1}

              #check right is desirable, propagated
              if(lattice[i%%n + 1, (j + 1)%%n + 1] == 3) {Cplusplus = Cplusplus + 1}
              else {Cpluszero = Cpluszero + 1}
            }
        #check if we're at a desirable, unpropagated
        if(lattice[i%%n + 1,j%%n + 1] == 2) {

          #check lower-left is desirable, propagated
          if(lattice[(i + 1)%%n + 1, (j - 1)%%n + 1] == 3) {Gpluszero = Gpluszero + 1}
          #else it is desirable, unpropagated
          else {Gzerozero = Gzerozero + 1}

          #check bottom is undesirable, propagated
          if(lattice[(i + 1)%%n + 1, j%%n + 1] == 1) {Szeroplus = Szeroplus + 1}
          #else it is undesirable, unpropagated
          else {Szerozero = Szerozero + 1}

          #check lower-right desirable, propagated
          if(lattice[(i + 1)%%n + 1, (j + 1)%%n + 1] == 3) {Gpluszero = Gpluszero + 1}
          #else it is desirable, unpropagated
          else {Gzerozero = Gzerozero + 1}

          #check right is undesirable, propagated
          if(lattice[i%%n + 1, (j + 1)%%n + 1] == 1) {Szeroplus = Szeroplus + 1}
          #else it is undesirable, unpropagated
          else {Szerozero = Szerozero + 1}
        }

        #check if we're at an undesirable, unpropagated
        if(lattice[i%%n + 1,j%%n  + 1] == 0) {

          #check lower-left is undesirable, propagated
          if(lattice[(i + 1)%%n + 1, (j - 1)%%n + 1] == 1) {Hpluszero = Hpluszero + 1}
          #else it is undesirable, unpropagated
          else {Hzerozero = Hzerozero + 1}

          #check bottom is desirable, propagated
          if(lattice[(i + 1)%%n + 1, j%%n + 1] == 3) {Czeroplus = Czeroplus + 1}
          #else it is desirable, unpropagated
          else {Czerozero = Czerozero + 1}

          #check lower-right is undesirable, propagated
          if(lattice[(i + 1)%%n + 1, (j + 1)%%n + 1] == 1) {Hpluszero = Hpluszero + 1}
          #else it is undesirable, unpropagated
          else {Hzerozero = Hzerozero + 1}

          #check right is desirable, propagated
          if(lattice[i%%n + 1, (j + 1)%%n + 1] == 3) {Czeroplus = Czeroplus + 1}
          else {Czerozero = Czerozero + 1}
        }
      }
    }

    #append new values to list
    all_counts <- c(all_counts, Gplusplus/total_pairs, Hplusplus/total_pairs, Splusplus/total_pairs, Cplusplus/total_pairs, Gpluszero/total_pairs,
                    Hpluszero/total_pairs, Spluszero/total_pairs, Cpluszero/total_pairs, Szeroplus/total_pairs, Czeroplus/total_pairs,
                    Gzerozero/total_pairs, Hzerozero/total_pairs, Szerozero/total_pairs, Czerozero/total_pairs)
  }

  return(all_counts)
}


