## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(EcologyStats)

## -----------------------------------------------------------------------------
mat <- c(3,1,3,1,1,3,1,3,3,1,3,1,1,3,1,3)
mat <- matrix(mat, 4, 4, byrow=TRUE)

lattice_calc(mat, w=0.75, option=2)

## -----------------------------------------------------------------------------

all_data <- rep(c(0.1,0.4,0.45, 0.7, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7), 10)
all_data <- c(all_data, rep(c(0.2,0.4,0.45, 0.7, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7), 10))
all_data <- c(all_data, rep(c(0.3,0.4,0.45, 0.7, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7), 10))
all_data <- c(all_data, rep(c(0.8,0.4,0.45, 0.7, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7), 10))
all_data <- matrix(all_data, nrow=40, ncol=17, byrow=TRUE)


head(calcavgvar(all_data))

## -----------------------------------------------------------------------------
file_path = "/Users/skylermoomey/Desktop/Research Functions/simulation_statistics/EcologyStats/csv/model_output_3over8.csv"
model_output <- read.csv(file_path)
mean_and_var <- c(0.0025, rep(0.0002, 33))
mean_and_var <- c(mean_and_var,rep(mean_and_var, 398))
mean_and_var <- matrix(mean_and_var, 399, 34, byrow=TRUE)
mean_and_var <- data.frame(mean_and_var)
head(comparedata(model_output, mean_and_var))

